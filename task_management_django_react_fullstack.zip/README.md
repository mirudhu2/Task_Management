# Task Management Full Stack - Django REST API + React

## Backend
cd backend
python -m venv venv
# Windows: venv\Scripts\activate
# Linux/macOS: source venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py runserver

Backend API: http://127.0.0.1:8000/api/tasks/

## Frontend
Open a second terminal:
cd frontend
npm install
npm run dev

React app: http://localhost:5173

## Features
- Create, read, update, delete tasks
- Status and priority
- Due date
- Search
- Status filtering
- Django REST Framework browsable API
- React UI using Axios
- CORS configured for Vite
