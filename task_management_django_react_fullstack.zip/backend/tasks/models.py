from django.db import models
class Task(models.Model):
    STATUS_CHOICES = [
        ("pending","Pending"),("in_progress","In Progress"),("completed","Completed")
    ]
    PRIORITY_CHOICES = [("low","Low"),("medium","Medium"),("high","High")]
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default="medium")
    due_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        ordering = ["-created_at"]
    def __str__(self): return self.title
