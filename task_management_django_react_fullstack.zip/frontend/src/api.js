import axios from "axios";
const api = axios.create({baseURL:"http://127.0.0.1:8000/api/"});
export const getTasks = (params={}) => api.get("tasks/", {params});
export const createTask = data => api.post("tasks/", data);
export const updateTask = (id, data) => api.put(`tasks/${id}/`, data);
export const deleteTask = id => api.delete(`tasks/${id}/`);
export default api;
