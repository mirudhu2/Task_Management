import { useEffect, useState } from "react";
import { getTasks, createTask, updateTask, deleteTask } from "./api";

const empty = {title:"", description:"", status:"pending", priority:"medium", due_date:""};

export default function App(){
  const [tasks,setTasks]=useState([]);
  const [form,setForm]=useState(empty);
  const [editing,setEditing]=useState(null);
  const [search,setSearch]=useState("");
  const [status,setStatus]=useState("");
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState("");

  const load = async () => {
    setLoading(true); setError("");
    try {
      const res=await getTasks({search:search||undefined,status:status||undefined});
      setTasks(res.data.results ?? res.data);
    } catch(e){ setError("Cannot connect to Django API. Start the backend server."); }
    finally{setLoading(false);}
  };

  useEffect(()=>{load()},[search,status]);

  const submit=async(e)=>{
    e.preventDefault();
    if(!form.title.trim()) return;
    try{
      if(editing) await updateTask(editing,form);
      else await createTask(form);
      setForm(empty); setEditing(null); load();
    }catch(e){setError("Unable to save task.");}
  };

  const edit=(t)=>{
    setEditing(t.id);
    setForm({title:t.title,description:t.description,status:t.status,priority:t.priority,due_date:t.due_date||""});
    window.scrollTo({top:0,behavior:"smooth"});
  };

  const remove=async(id)=>{
    if(confirm("Delete this task?")){await deleteTask(id);load();}
  };

  return <div className="container">
    <header><h1>Task Management</h1><p>Django REST API + React</p></header>

    <section className="card">
      <h2>{editing ? "Edit Task" : "Create Task"}</h2>
      <form onSubmit={submit} className="form">
        <input placeholder="Task title" value={form.title}
          onChange={e=>setForm({...form,title:e.target.value})}/>
        <textarea placeholder="Description" value={form.description}
          onChange={e=>setForm({...form,description:e.target.value})}/>
        <div className="grid">
          <select value={form.status} onChange={e=>setForm({...form,status:e.target.value})}>
            <option value="pending">Pending</option><option value="in_progress">In Progress</option><option value="completed">Completed</option>
          </select>
          <select value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})}>
            <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option>
          </select>
          <input type="date" value={form.due_date} onChange={e=>setForm({...form,due_date:e.target.value})}/>
        </div>
        <button type="submit">{editing ? "Update Task" : "Add Task"}</button>
        {editing && <button type="button" className="secondary" onClick={()=>{setEditing(null);setForm(empty)}}>Cancel</button>}
      </form>
    </section>

    <section className="toolbar">
      <input placeholder="Search tasks..." value={search} onChange={e=>setSearch(e.target.value)}/>
      <select value={status} onChange={e=>setStatus(e.target.value)}>
        <option value="">All Status</option><option value="pending">Pending</option>
        <option value="in_progress">In Progress</option><option value="completed">Completed</option>
      </select>
    </section>

    {error && <div className="error">{error}</div>}
    {loading ? <p>Loading...</p> :
      <section className="tasks">
        {tasks.length===0 ? <div className="card">No tasks found.</div> :
        tasks.map(t=><article className="task" key={t.id}>
          <div><h3>{t.title}</h3><p>{t.description}</p></div>
          <div className="meta">
            <span>{t.status.replace("_"," ")}</span><span>{t.priority}</span>
            {t.due_date && <span>Due: {t.due_date}</span>}
          </div>
          <div className="actions"><button onClick={()=>edit(t)}>Edit</button><button className="danger" onClick={()=>remove(t.id)}>Delete</button></div>
        </article>)}
      </section>
    }
  </div>
}
